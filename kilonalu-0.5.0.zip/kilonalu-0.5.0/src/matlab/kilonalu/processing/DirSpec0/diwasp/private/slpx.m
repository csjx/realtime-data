function trm=velx(ffreqs,dirs,wns,z,depth)

trm=(i*wns)*cos(dirs);