function trm=elev(ffreqs,dirs,wns,z,depth)

trm=ones(size(ffreqs,1),size(dirs,2));